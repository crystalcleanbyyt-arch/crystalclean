Put your image files here with these names:
hero-kitchen.png
sink-before-1.jpeg
sink-after-1.jpeg
vanity-after-1.jpeg
toilet-before-1.jpeg
toilet-after-1.jpeg
kitchen-before-1.jpeg
kitchen-after-1.jpeg
floor-before-1.jpeg
floor-after-1.jpeg
vanity-before-1.jpeg
vanity-after-1.jpeg
toiletbase-before-1.jpeg
toiletbase-after-1.jpeg
